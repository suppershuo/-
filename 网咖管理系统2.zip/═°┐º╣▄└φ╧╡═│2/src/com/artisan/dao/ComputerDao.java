package com.artisan.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.artisan.model.Computer;
import com.artisan.model.Customer;
import com.artisan.model.Area;
import com.artisan.util.StringUtil;

/**
 * 
 * ������Ϣ�����ݿ�Ĳ���
 * @author llq
 *
 */
public class ComputerDao extends BaseDao {
	public boolean addClass(Computer c){
		String sql = "insert into s_computer values(?,?,?,?,?)";
		try {
			java.sql.PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setInt(1, c.getNum());
			preparedStatement.setString(2, c.getState());
			preparedStatement.setString(3, c.getUser());
			preparedStatement.setString(4, c.getArea());
			preparedStatement.setString(5, c.getBeginTime());
			if(preparedStatement.executeUpdate() > 0)return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public Computer findComputer(int n) {
		String sqlString = "select * from s_computer where num='"+n+"'";
		Computer sc = new Computer();
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sqlString);
			ResultSet executeQuery = preparedStatement.executeQuery();
			while(executeQuery.next()){
				sc.setNum(executeQuery.getInt("num"));
				sc.setState(executeQuery.getString("state"));
				sc.setUser(executeQuery.getString("user"));
				sc.setArea(executeQuery.getString("area"));
				sc.setBeginTime(executeQuery.getString("begintime"));
				sc.setUserid(executeQuery.getInt("userid"));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sc;
	}
	//��ȡ����״̬�����л���
	public List<Computer> getComputerList(String state){
		List<Computer> retList = new ArrayList<Computer>();
		String sqlString = "select * from s_computer where state='"+state+"'";
		
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sqlString);
			ResultSet executeQuery = preparedStatement.executeQuery();
			while(executeQuery.next()){
				Computer sc = new Computer();
				sc.setNum(executeQuery.getInt("num"));
				sc.setState(executeQuery.getString("state"));
				sc.setUser(executeQuery.getString("user"));
				sc.setArea(executeQuery.getString("area"));
				sc.setBeginTime(executeQuery.getString("begintime"));
				sc.setUserid(executeQuery.getInt("userid"));
				retList.add(sc);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return retList;
	}
	//��ȡ���л���
	public List<Computer> getComputerList(){
		List<Computer> retList = new ArrayList<Computer>();
		String sqlString = "select * from s_computer";
		
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sqlString);
			ResultSet executeQuery = preparedStatement.executeQuery();
			while(executeQuery.next()){
				Computer sc = new Computer();
				sc.setNum(executeQuery.getInt("num"));
				sc.setState(executeQuery.getString("state"));
				sc.setUser(executeQuery.getString("user"));
				sc.setArea(executeQuery.getString("area"));
				sc.setBeginTime(executeQuery.getString("begintime"));
				sc.setUserid(executeQuery.getInt("userid"));
				retList.add(sc);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(retList);
		return retList;
	}
	public boolean delete(int id){
		String sql = "delete from s_computer where id=?";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setInt(1, id);
			if(preparedStatement.executeUpdate() > 0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	//�ϻ�ʱ���»���״̬
	public boolean update(Computer sc,Customer cs,String state){
		String sql = "update s_computer set state=?, user=?, where num=?";
		if(state.equals("����")||state.equals("ʹ����")||state.equals("��")) {
			try {
				PreparedStatement preparedStatement = con.prepareStatement(sql);
				preparedStatement.setString(1, state);
				preparedStatement.setString(2, cs.getName());
				preparedStatement.setInt(3, sc.getNum());
				if(preparedStatement.executeUpdate() > 0){
					return true;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
	//��������
	public boolean update(Computer sc,Area a){
		String sql = "update s_computer set area=? where num=?";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setString(1, a.getName());
			preparedStatement.setInt(3, sc.getNum());
			if(preparedStatement.executeUpdate() > 0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public boolean update(int num){
		String sql = "update s_computer set state='δʹ��',user='��',userid=0,begintime='' where num=?";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setInt(1, num);
			if(preparedStatement.executeUpdate() > 0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
}

