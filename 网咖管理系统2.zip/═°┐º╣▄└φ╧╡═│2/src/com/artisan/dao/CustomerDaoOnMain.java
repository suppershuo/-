package com.artisan.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.artisan.model.Admin;
import com.artisan.model.Customer;
import com.artisan.model.Area;
import com.artisan.util.StringUtil;

public class CustomerDaoOnMain extends BaseDao {
	public boolean addCustomer(Customer customer){
		//INSERT INTO `s_customer` (`id`, `name`, `password`, `computer`) VALUES ('32', '��', '3', '39')
		String sql = "insert into s_customer values(?,?,?,?,?,?,?)";
		String sql2="update s_computer set state=?,user=?,begintime=?,userid=? where num=?";
		try {
			java.sql.PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setInt(1, customer.getId());
			preparedStatement.setString(2, customer.getName());
			preparedStatement.setInt(3, customer.getAreaId());
			preparedStatement.setString(4, customer.getPassword());
			preparedStatement.setString(5, customer.getSex());
			preparedStatement.setInt(6, customer.getComputer());
			preparedStatement.setString(7, customer.getontime());
			if(preparedStatement.executeUpdate() > 0)
			{
				java.sql.PreparedStatement preparedStatement2 = con.prepareStatement(sql2);
				preparedStatement2.setString(1, "ʹ����");
				preparedStatement2.setString(2, customer.getName());
				preparedStatement2.setString(3, customer.getontime());
				preparedStatement2.setInt(4, customer.getId());
				preparedStatement2.setInt(5, customer.getComputer());
				preparedStatement2.executeUpdate();
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
}
