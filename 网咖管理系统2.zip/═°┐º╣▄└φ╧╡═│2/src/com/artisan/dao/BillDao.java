package com.artisan.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.artisan.model.Admin;
import com.artisan.model.Customer;
import com.artisan.model.Area;
import com.artisan.model.Bill;
import com.artisan.util.StringUtil;

public class BillDao extends BaseDao {
	public boolean addBill(Bill bill){
		String sql = "insert into s_bill values(?,?,?,?,?,null,0,'',0)";
		try {
			java.sql.PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setString(1, bill.getBid());
			preparedStatement.setInt(2, bill.getUserid());
			preparedStatement.setString(3, bill.getUsername());
			preparedStatement.setInt(4, bill.getComid());
			preparedStatement.setString(5, bill.getBegintime());
			if(preparedStatement.executeUpdate() > 0)
			{
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public List<Bill> getBillList(){
		List<Bill> retList = new ArrayList<Bill>();
		String sqlString = "select * from s_bill";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sqlString);
			ResultSet executeQuery = preparedStatement.executeQuery();
			while(executeQuery.next()){
				Bill b = new Bill();
				b.setBid(executeQuery.getString("bid"));
				b.setUserid(executeQuery.getInt("userid"));
				b.setUsername(executeQuery.getString("username"));
				b.setComid(executeQuery.getInt("comid"));
				b.setBegintime(executeQuery.getString("begintime"));
				b.setOvertime(executeQuery.getString("overtime"));
				b.setNetcost(executeQuery.getFloat("netcost"));
				b.setFoodcost(executeQuery.getString("foodcost"));
				b.setCost(executeQuery.getFloat("cost"));
				retList.add(b);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return retList;
	}
	public boolean delete(String id){
		String sql = "delete from s_bill where bid=?";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setString(1, id);
			if(preparedStatement.executeUpdate() > 0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public boolean update(Bill bill){
		String sql = "update s_bill set overtime=?, netcost=?,foodcost=?,cost=? where bid=?";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setString(1, bill.getOvertime());
			preparedStatement.setFloat(2, bill.getNetcost());
			preparedStatement.setString(3, bill.getFoodcost());
			preparedStatement.setFloat(4, bill.getCost());
			preparedStatement.setString(5, bill.getBid());
			if(preparedStatement.executeUpdate() > 0){
				System.out.println("ook");
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
}
