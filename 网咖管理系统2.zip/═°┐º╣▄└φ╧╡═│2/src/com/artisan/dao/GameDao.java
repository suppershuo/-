package com.artisan.dao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.artisan.model.Customer;
import com.artisan.model.Game;
import com.artisan.util.StringUtil;
public class GameDao extends BaseDao {
		public boolean addGame(Game game){
			String sql = "insert into s_game(��Ϸ����,��Ϸ����,��Ϸ�۸�,��Ϸ��)  values(?,?,?,?)";
			try {
				java.sql.PreparedStatement preparedStatement = con.prepareStatement(sql);
				preparedStatement.setString(1, game.getsname());
				preparedStatement.setString(2, game.getstype());
				preparedStatement.setFloat(3, game.getsprice());
				preparedStatement.setString(4, game.getProduct());
				if(preparedStatement.executeUpdate() > 0)return true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return false;
		}

		public List<Game> getGameList(Game game) {
			// TODO Auto-generated method stub
			List<Game> retList = new ArrayList<Game>();
			StringBuffer sqlString = new StringBuffer("select * from s_game");
			if(!StringUtil.isEmpty(game.getsname())){
				sqlString.append(" where ��Ϸ����  like '%"+game.getsname()+"%'");
			}
			try {
				PreparedStatement preparedStatement = con.prepareStatement(sqlString.toString());
				ResultSet executeQuery = preparedStatement.executeQuery();
				while(executeQuery.next()){
					Game t = new Game();
					t.setsname(executeQuery.getString("��Ϸ����"));
					t.setstype(executeQuery.getString("��Ϸ����"));
					t.setsprice(executeQuery.getFloat("��Ϸ�۸�"));
					t.setProduct(executeQuery.getString("��Ϸ��"));
					retList.add(t);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return retList;
		}
		public boolean delete(String sname){
			String sql = "delete from s_game where ��Ϸ����  = ?";
			try {
				PreparedStatement preparedStatement = con.prepareStatement(sql);
				preparedStatement.setString(1, sname);
				if(preparedStatement.executeUpdate() > 0){
					return true;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return false;
		}
		public boolean update(Game food){
			String sql = "update s_game set ��Ϸ����=?,��Ϸ����=?,��Ϸ�۸�=?   where ��Ϸ��=? ";
			try {
				PreparedStatement preparedStatement = con.prepareStatement(sql);
				
				preparedStatement.setString(1, food.getsname());
				preparedStatement.setString(2, food.getstype());
				preparedStatement.setFloat(3, food.getsprice());
				preparedStatement.setString(4,food.getProduct());
				if(preparedStatement.executeUpdate() > 0){
					return true;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return false;
		}
}
