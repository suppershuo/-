package com.artisan.view;

import javax.swing.JInternalFrame;
import java.awt.EventQueue;

import javax.swing.ButtonGroup;
import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JRadioButton;
import javax.swing.JButton;

import com.artisan.dao.GameDao;
import com.artisan.model.Game;
import com.artisan.util.StringUtil;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JDesktopPane;
public class AddGameFrm extends JInternalFrame{
    private JTextField gameNameTextField;
	private JTextField gameTypeTextField;
	private JTextField gamePriceTextField;
	private JTextField gameProductField;
	public AddGameFrm() {
		setClosable(true);
		setIconifiable(true);
		setTitle("\u6DFB\u52A0\u6E38\u620F");
		setBounds(100, 100, 450, 371);
		
		JLabel label = new JLabel("\u6E38\u620F\u540D\u79F0\uFF1A");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		label.setIcon(null);
		
		gameNameTextField = new JTextField();
		gameNameTextField.setColumns(10);
		
		JLabel label_2 = new JLabel("\u6E38\u620F\u7C7B\u578B\uFF1A");
		label_2.setIcon(null);
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		gameTypeTextField = new JTextField();
		gameTypeTextField.setColumns(10);
		
		JLabel label_3 = new JLabel("\u6E38\u620F\u4EF7\u683C\uFF1A");
		label_3.setIcon(null);
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		gamePriceTextField = new JTextField();
		gamePriceTextField.setColumns(10);
		
		JButton submitButton = new JButton("\u786E\u8BA4\u6DFB\u52A0");
		submitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				addGameAct(ae);
			}
		});
		submitButton.setIcon(new ImageIcon(AddFoodFrm.class.getResource("/images/\u786E\u8BA4.png")));
		submitButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JButton resetButton = new JButton("\u91CD\u7F6E\u8868\u5355");
		resetButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				resetValue(ae);
			}
		});
		resetButton.setIcon(new ImageIcon(AddFoodFrm.class.getResource("/images/\u91CD\u7F6E.png")));
		resetButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JLabel lblid = new JLabel("\u6E38\u620FID\uFF1A");
		lblid.setIcon(null);
		lblid.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		gameProductField = new JTextField();
		gameProductField.setColumns(10);
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(87)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(label)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(gameNameTextField, GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(submitButton)
							.addPreferredGap(ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
							.addComponent(resetButton))
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(label_2)
								.addComponent(label_3)
								.addComponent(lblid))
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(gameProductField, GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE)
								.addComponent(gamePriceTextField, GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE)
								.addComponent(gameTypeTextField, 152, 168, Short.MAX_VALUE))))
					.addGap(95))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(68)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(gameNameTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(27)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_2)
						.addComponent(gameTypeTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(27)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_3)
						.addComponent(gamePriceTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(30)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblid)
						.addComponent(gameProductField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(submitButton)
						.addComponent(resetButton))
					.addGap(32))
		);
		getContentPane().setLayout(groupLayout);

	}

	protected void resetValue(ActionEvent ae) {
		// TODO Auto-generated method stub
		gameNameTextField.setText("");
		gameTypeTextField.setText("");
		gamePriceTextField.setText("");
		gameProductField.setText("");
	}

	protected void addGameAct(ActionEvent ae) {
		// TODO Auto-generated method stub
		String gameName = gameNameTextField.getText().toString();
		String gameType = gameTypeTextField.getText().toString();
		String gameProduct = gameProductField.getText().toString();
		float gamePrice = 0;
		try {
			gamePrice = Integer.parseInt(gamePriceTextField.getText().toString());
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(this, "�۸�ֻ�����������֣�");
			return;
		}
		if(StringUtil.isEmpty(gameName)){
			JOptionPane.showMessageDialog(this, "��Ϸ���Ʊ�����д��");
			return;
		}
		if(StringUtil.isEmpty(gameType)){
			JOptionPane.showMessageDialog(this, "��Ϸ�������ͱ�����д��");
			return;
		}
		if( gamePrice < 0){
			JOptionPane.showMessageDialog(this, "�۸������ڵ���0��");
			return;
		}
		if(StringUtil.isEmpty(gameProduct)){
			JOptionPane.showMessageDialog(this, "��Ϸ�ű�����д��");
			return;
		}
		Game game = new Game();
		game.setsname(gameName);
		game.setstype(gameType);
		game.setsprice(gamePrice);
		game.setProduct(gameProduct);
		GameDao gameDao = new GameDao();
		if(gameDao.addGame(game)){
			JOptionPane.showMessageDialog(this, "��Ϸ���ӳɹ���");
		}else{
			JOptionPane.showMessageDialog(this, "��Ϸ����ʧ�ܣ�");
		}
		resetValue(ae);
	}
}