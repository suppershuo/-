package com.artisan.view;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import java.util.Vector;

import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import com.artisan.dao.GameDao;
import com.artisan.model.Game;
import com.artisan.util.StringUtil;
import java.awt.Color;
public class ManageGameFrm extends JInternalFrame  {
	private JTable gameListTable;
	private JTextField searchGameNameTextField;
	private JTextField editGameNameTextField;
	private JTextField editGameTypeTextField;
	private JTextField editGamepriceTextField;
	private JTextField editGameProductField;
	private JButton deleteGameButton;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManageGameFrm frame = new ManageGameFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManageGameFrm() {
		setClosable(true);
		setIconifiable(true);
		setTitle("\u6E38\u620F\u4FE1\u606F\u7BA1\u7406");
		setBounds(100, 100, 805, 691);
		
		JScrollPane scrollPane = new JScrollPane();
		
		JLabel label = new JLabel("\u6E38\u620F\u540D\u79F0\uFF1A");
		label.setIcon(null);
		label.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		searchGameNameTextField = new JTextField();
		searchGameNameTextField.setColumns(10);
		
		JButton searchGameButton = new JButton("\u67E5\u8BE2");
		searchGameButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searchGame(e);
			}
		});
		searchGameButton.setIcon(new ImageIcon(ManageGameFrm.class.getResource("/images/\u641C\u7D22.png")));
		searchGameButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "\u98DF\u54C1\u4FE1\u606F\u4FEE\u6539", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(178)
							.addComponent(label)
							.addGap(33)
							.addComponent(searchGameNameTextField, GroupLayout.PREFERRED_SIZE, 179, GroupLayout.PREFERRED_SIZE)
							.addGap(66)
							.addComponent(searchGameButton))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(92)
							.addComponent(panel, GroupLayout.DEFAULT_SIZE, 610, Short.MAX_VALUE)))
					.addContainerGap(87, Short.MAX_VALUE))
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(65)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 610, Short.MAX_VALUE)
					.addGap(114))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(33)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(searchGameNameTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label)
						.addComponent(searchGameButton))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 323, GroupLayout.PREFERRED_SIZE)
					.addGap(36)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 175, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(52, Short.MAX_VALUE))
		);
		
		JLabel label_1 = new JLabel("\u6E38\u620F\u540D\u79F0\uFF1A");
		label_1.setIcon(null);
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		editGameNameTextField = new JTextField();
		editGameNameTextField.setColumns(10);
		
		ButtonGroup buttonGroup = new ButtonGroup();
		
		JLabel label_3 = new JLabel("\u6E38\u620F\u7C7B\u578B\uFF1A");
		label_3.setIcon(null);
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		editGameTypeTextField = new JTextField();
		editGameTypeTextField.setColumns(10);
		
		JLabel label_4 = new JLabel("\u6E38\u620F\u4EF7\u683C\uFF1A");
		label_4.setIcon(null);
		label_4.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		editGamepriceTextField = new JTextField();
		editGamepriceTextField.setColumns(10);
		
		JLabel lblid = new JLabel("\u6E38\u620F\u53F7\uFF1A");
		lblid.setIcon(null);
		lblid.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		editGameProductField = new JTextField();
		
		JButton editGameSubmitButton = new JButton("\u786E\u8BA4\u4FEE\u6539");
		editGameSubmitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				editGameAct(ae);
			}
		});
		editGameSubmitButton.setIcon(new ImageIcon(ManageGameFrm.class.getResource("/images/\u786E\u8BA4.png")));
		editGameSubmitButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		deleteGameButton = new JButton("\u5220\u9664\u4FE1\u606F");
		deleteGameButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				deleteGame(ae);
			}
		});
		deleteGameButton.setIcon(new ImageIcon(ManageGameFrm.class.getResource("/images/\u5220\u9664.png")));
		deleteGameButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(24)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(label_1)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(editGameNameTextField, GroupLayout.PREFERRED_SIZE, 122, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(label_3)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(editGameSubmitButton)
								.addComponent(editGameTypeTextField, GroupLayout.PREFERRED_SIZE, 124, GroupLayout.PREFERRED_SIZE))))
					.addGap(26)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(label_4)
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(lblid)
							.addGap(18)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
								.addComponent(editGameProductField)
								.addComponent(editGamepriceTextField, GroupLayout.DEFAULT_SIZE, 129, Short.MAX_VALUE)
								.addComponent(deleteGameButton, Alignment.TRAILING))))
					.addContainerGap(144, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_1)
						.addComponent(editGameNameTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_4)
						.addComponent(editGamepriceTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_3)
						.addComponent(editGameTypeTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblid)
						.addComponent(editGameProductField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(29)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(editGameSubmitButton)
						.addComponent(deleteGameButton))
					.addGap(19))
		);
		panel.setLayout(gl_panel);
		
		gameListTable = new JTable();
		gameListTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				selectedTableRow(arg0);
			}
		});
		gameListTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u6E38\u620F\u540D\u79F0", "\u6E38\u620F\u7C7B\u578B", "\u6E38\u620F\u4EF7\u683C", "\u6E38\u620F\u53F7"
			}
		));
		scrollPane.setViewportView(gameListTable);
		getContentPane().setLayout(groupLayout);
		setTable(new Game());
		setAuthority();
	}
	protected void editGameAct(ActionEvent ae) {
		// TODO Auto-generated method stub
		int row = gameListTable.getSelectedRow();
		if(row == -1){
			JOptionPane.showMessageDialog(this, "��ѡ��Ҫ�޸ĵ����ݣ�");
			return;
		}
		String gameName = editGameNameTextField.getText().toString();
		String gameType = editGameTypeTextField.getText().toString();
		int gamePrice = 0;
		try {
			gamePrice = Integer.parseInt(editGamepriceTextField.getText().toString());
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(this, "�۸�ֻ�����������֣�");
			return;
		}
		String gameProduct = editGameProductField.getText().toString();
		if(StringUtil.isEmpty(gameName)){
			JOptionPane.showMessageDialog(this, "��Ϸ���Ʊ�����д��");
			return;
		}
		if(StringUtil.isEmpty(gameType)){
			JOptionPane.showMessageDialog(this, "��Ϸ���ͱ�����д��");
			return;
		}
		if( gamePrice < 0){
			JOptionPane.showMessageDialog(this, "�۸������ڵ���0��");
			return;
		}
		if(StringUtil.isEmpty(gameProduct)){
			JOptionPane.showMessageDialog(this, "��Ϸ�ű�����д��");
			return;
		}
		Game game = new Game();
		//game.setId(Integer.parseInt(gameListTable.getValueAt(row, 0).toString()));
		game.setsname(gameName);
		game.setstype(gameType);
		game.setsprice(gamePrice);
		game.setProduct(gameProduct);
		GameDao gameDao = new GameDao();
		if(gameDao.update(game)){
			JOptionPane.showMessageDialog(this, "�޸ĳɹ���");
		}else{
			JOptionPane.showMessageDialog(this, "�޸�ʧ�ܣ�");
		}
		gameDao.closeDao();
		setTable(new Game());
	}

	protected void searchGame(ActionEvent e) {
		// TODO Auto-generated method stub
		String gameNameString = searchGameNameTextField.getText().toString();
		Game game = new Game();
		game.setsname(gameNameString);
		setTable(game);
	}

	protected void deleteGame(ActionEvent ae) {
		// TODO Auto-generated method stub
		int row = gameListTable.getSelectedRow();
		if(row == -1){
			JOptionPane.showMessageDialog(this, "��ѡ��Ҫɾ�������ݣ�");
			return;
		}
		if(JOptionPane.showConfirmDialog(this, "ȷ��Ҫɾ��ô��") != JOptionPane.OK_OPTION)return;
		String snames = (String) gameListTable.getValueAt(row, 0);
		GameDao gameDao = new GameDao();
		if(gameDao.delete(snames)){
			JOptionPane.showMessageDialog(this, "ɾ���ɹ���");
		}else{
			JOptionPane.showMessageDialog(this, "ɾ��ʧ�ܣ�");
		}
		gameDao.closeDao();
		setTable(new Game());
	}

	private void setTable(Game game){
		System.out.println("ok");
		if("�ͻ�".equals(MainFrm.userType.getName())){
			Game tLogined = (Game) MainFrm.userObject;
			game.setsname(tLogined.getsname());
			searchGameNameTextField.setText(game.getsname());
		}
		System.out.println("ok");
		DefaultTableModel dft = (DefaultTableModel) gameListTable.getModel();
		dft.setRowCount(0);
		GameDao gameDao = new GameDao();
		List<Game> gameList = gameDao.getGameList(game);
		System.out.println("ok");
		for (Game t : gameList) {
			Vector v = new Vector();
			v.add(t.getsname());
			v.add(t.getstype());
			v.add(t.getsprice());
			v.add(t.getProduct());
			dft.addRow(v);
		}
		gameDao.closeDao();
	}
	protected void selectedTableRow(MouseEvent me) {
		// TODO Auto-generated method stub
		DefaultTableModel dft = (DefaultTableModel) gameListTable.getModel();
		editGameNameTextField.setText(dft.getValueAt(gameListTable.getSelectedRow(), 0).toString());
		editGameTypeTextField.setText(dft.getValueAt(gameListTable.getSelectedRow(), 1).toString());
		editGamepriceTextField.setText(dft.getValueAt(gameListTable.getSelectedRow(), 2).toString());
		editGameProductField.setText(dft.getValueAt(gameListTable.getSelectedRow(), 3).toString());
	}
	private void setAuthority(){
		if("�ͻ�".equals(MainFrm.userType.getName())){
			deleteGameButton.setEnabled(false);
			searchGameNameTextField.setEditable(false);
		}
	}
}

