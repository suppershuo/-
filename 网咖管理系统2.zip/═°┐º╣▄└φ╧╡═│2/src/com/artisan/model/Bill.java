package com.artisan.model;

//�˵�
public class Bill {
	private String bid;
	private int userid;
	private String username;
	private int comid;
	private String begintime;
	private String overtime;
	private float netcost;
	private String foodcost;
	private float cost;
	
	public void setBid(String b) {
		bid=b;
	}
	public String getBid() {
		return bid;
	}
	public void setUserid(int u) {
		userid=u;
	}
	public int getUserid() {
		return userid;
	}
	public void setUsername(String u) {
		username=u;
	}
	public String getUsername() {
		return username;
	}
	public void setComid(int c) {
		comid=c;
	}
	public int getComid() {
		return comid;
	}
	public void setBegintime(String t) {
		begintime=t;
	}
	public String getBegintime() {
		return begintime;
	}
	public void setOvertime(String t) {
		overtime=t;
	}
	public String getOvertime() {
		return overtime;
	}
	public void setNetcost(float n) {
		netcost=n;
	}
	public float getNetcost(){
		return netcost;
	}
	public void setFoodcost(String s) {
		foodcost=s;
	}
	public String getFoodcost() {
		return foodcost;
	}
	public void setCost(float n) {
		cost=n;
	}
	public float getCost(){
		return cost;
	}
}
