﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void login_Click(object sender, EventArgs e)
        {
            string stuID = zhanghao.Text;
            string pwd = mima.Text;

            string connectionString = "Server=(local);Database=TextDB;Integrated Security=true;";
            //string connectionString = "Server=(local);Database=TextDB;UID=sa;PWD=sq12008;";
            SqlConnection connection = new SqlConnection(connectionString);
            bool verified = false;
            connection.Open();
            string queryString = "SELECT * FROM Student;";
            SqlCommand command = new SqlCommand(queryString, connection);

            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                if (stuID == reader[0].ToString() && pwd == reader[1].ToString())
                {
                    verified = true;
                }
            }
            reader.Close();
            connection.Close();
            if (verified) Response.Write("<script>alert('登录成功');</script>");
            else Response.Write("<script>alert('登录失败');</script>");
        }
    }
}
