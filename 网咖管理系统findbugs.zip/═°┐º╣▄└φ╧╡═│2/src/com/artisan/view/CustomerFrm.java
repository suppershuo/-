package com.artisan.view;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URI;
import java.nio.channels.SelectionKey;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Vector;
import java.awt.event.*;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.artisan.dao.AreaDao;
import com.artisan.dao.BillDao;
import com.artisan.dao.CustomerDao;
import com.artisan.dao.CustomerDaoOnMain;
import com.artisan.model.Area;
import com.artisan.model.Bill;
import com.artisan.model.Customer;
import com.artisan.model.UserType;
import com.artisan.model.Computer;
import com.artisan.dao.ComputerDao;
import com.artisan.util.StringUtil;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.artisan.view.MainFrm;

public class CustomerFrm extends JFrame{
	private int comnum;
	private int cusnum;
	private String begint;
	private int hours;
	public CustomerFrm(Customer customer) {
		comnum=customer.getComputer();
		cusnum=customer.getId();
		begint=customer.getontime();
		
		setTitle("\u7535\u8111");
		
		JDesktopPane desktopPane = new JDesktopPane();
		desktopPane.setBackground(Color.LIGHT_GRAY);
		getContentPane().add(desktopPane, BorderLayout.CENTER);
		
		JLabel lblNewLabel = new JLabel(comnum+"�Ż�");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 40));
		lblNewLabel.setBounds(273, 59, 147, 60);
		desktopPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("\u4E0B\u673A");
		btnNewButton.setBounds(14, 443, 113, 27);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Date date = new Date();//���ϵͳʱ��.
				String nowTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);//��ʱ���ʽת���ɷ���Ҫ��ĸ�ʽ.
				try {
					Calendar c = Calendar.getInstance();
	                c.setTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(nowTime));
	                long endsecond=c.getTimeInMillis();
	                System.out.println(endsecond);
	                Calendar c2 = Calendar.getInstance();
	                System.out.println(begint);
	                c2.setTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(begint));
	                long beginsecond=c2.getTimeInMillis();
	                System.out.println(beginsecond);
	                int re=(int)endsecond-(int)beginsecond;
	                System.out.println(re);
	                hours=(int)(re/1000/60/60)+1;
				}
				catch(ParseException p) {
					
				}
			    float netcost=hours*5;
				String foodcost="";
				float cost=netcost;
				ComputerDao comDao=new ComputerDao();
				CustomerDao cusDao=new CustomerDao();
				BillDao billDao=new BillDao();
				Bill bill=new Bill();
				bill.setBid(cusnum+begint);
				bill.setOvertime(nowTime);
				bill.setNetcost(netcost);
				bill.setFoodcost(foodcost);
				bill.setCost(cost);
				billDao.update(bill);
				comDao.update(comnum);
				cusDao.delete(cusnum);
				comDao.closeDao();
				cusDao.closeDao();
				billDao.closeDao();
				dispose();
			}
		});
		desktopPane.add(btnNewButton);
		setBounds(100, 100, 650, 600);
		this.setVisible(true);
	}
	
}
