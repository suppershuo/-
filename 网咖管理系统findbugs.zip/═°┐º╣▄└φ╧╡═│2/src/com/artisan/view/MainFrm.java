package com.artisan.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URI;
import java.nio.channels.SelectionKey;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Vector;
import java.awt.event.*;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.artisan.dao.AreaDao;
import com.artisan.dao.CustomerDao;
import com.artisan.dao.CustomerDaoOnMain;
import com.artisan.dao.BillDao;
import com.artisan.model.Area;
import com.artisan.model.Customer;
import com.artisan.model.UserType;
import com.artisan.model.Computer;
import com.artisan.dao.ComputerDao;
import com.artisan.util.StringUtil;
import com.artisan.model.Bill;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class MainFrm extends JFrame {

	private JPanel contentPane;
	private JDesktopPane desktopPane;
	public static UserType userType;
	public static Object userObject;
	private JMenuItem addCustomerMenuItem ;
	private JMenu manageAreaMenu ;
	private JMenu manageFoodMenu;
	private JMenuItem addFoodMenuItem;
	private JRadioButton customerSexManRadioButton;
	private JRadioButton customerSexFemalRadioButton;
	private JRadioButton customerSexUnkonwRadioButton;
	private ButtonGroup sexButtonGroup;
	private JTextField customerNameTextField;
	private JTextField customerComputertextField;
	private JPasswordField customerPasswordField;
	private JComboBox customerAreaComboBox;
	protected JTable table;
	protected String[] title= {"������","״̬","ʹ����","����","�ϻ�ʱ��"};
	protected DefaultTableModel model = new DefaultTableModel();
	protected String radiobuttonselected="����";
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
     				MainFrm frame = new MainFrm(null,null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}

	/**
	 * Create the frame.
	 */
	public MainFrm(UserType userType,Object userObject) {
		
		MainFrm.userType = userType;
		MainFrm.userObject = userObject;
		setTitle("\u7F51\u5496\u4FE1\u606F\u7CFB\u7EDF\u4E3B\u754C\u9762");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 936, 774);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu menu = new JMenu("\u7CFB\u7EDF\u8BBE\u7F6E");
		menu.setIcon(new ImageIcon(MainFrm.class.getResource("/images/\u7CFB\u7EDF\u8BBE\u7F6E.png")));
		menuBar.add(menu);
		
		JMenuItem menuItem = new JMenuItem("\u4FEE\u6539\u5BC6\u7801");
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				editPassword(ae);
			}
		});
		menuItem.setIcon(new ImageIcon(MainFrm.class.getResource("/images/\u4FEE\u6539\u5BC6\u7801.png")));
		menu.add(menuItem);
		
		JMenuItem menuItem_1 = new JMenuItem("\u9000\u51FA\u7CFB\u7EDF");
		menuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(JOptionPane.showConfirmDialog(MainFrm.this, "ȷ���˳�ô��") == JOptionPane.OK_OPTION){
					System.exit(0);
				}
			}
		});
		menuItem_1.setIcon(new ImageIcon(MainFrm.class.getResource("/images/\u9000\u51FA.png")));
		menu.add(menuItem_1);
		
		JMenu menu_1 = new JMenu("\u5BA2\u6237\u7BA1\u7406");
		menu_1.setIcon(new ImageIcon(MainFrm.class.getResource("/images/\u8001\u5E08.png")));
		menuBar.add(menu_1);
		
		addFoodMenuItem = new JMenuItem("\u5BA2\u6237\u6DFB\u52A0");
		addFoodMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddCustomerFrm addCustomerFrm = new AddCustomerFrm();
				addCustomerFrm.setVisible(true);
				desktopPane.add(addCustomerFrm);
			}
		});
		
		addFoodMenuItem.setIcon(new ImageIcon(MainFrm.class.getResource("/images/\u6DFB\u52A0.png")));
		menu_1.add(addFoodMenuItem);
		
		JMenuItem menuItem_3 = new JMenuItem("\u5BA2\u6237\u5217\u8868");
		menuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManageCustomerFrm customerManageFrm = new ManageCustomerFrm();
				customerManageFrm.setVisible(true);
				desktopPane.add(customerManageFrm);
			}
		});
		menuItem_3.setIcon(new ImageIcon(MainFrm.class.getResource("/images/\u7528\u6237\u5217\u8868.png")));
		menu_1.add(menuItem_3);
		
		addFoodMenuItem = new JMenu("\u673A\u533A\u7BA1\u7406");
		addFoodMenuItem.setIcon(new ImageIcon(MainFrm.class.getResource("/images/\u73ED\u7EA7\u7BA1\u7406.png")));
		menuBar.add(addFoodMenuItem);
		
		JMenuItem menuItem_4 = new JMenuItem("\u673A\u533A\u6DFB\u52A0");
		menuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				addCustomerArea(ae);
			}
		});
		menuItem_4.setIcon(new ImageIcon(MainFrm.class.getResource("/images/\u6DFB\u52A0.png")));
		addFoodMenuItem.add(menuItem_4);
		
		JMenuItem menuItem_5 = new JMenuItem("\u673A\u533A\u7BA1\u7406");
		menuItem_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ManageAreaFrm areaManageFrm = new ManageAreaFrm();
				areaManageFrm.setVisible(true);
				desktopPane.add(areaManageFrm);
			}
		});
		menuItem_5.setIcon(new ImageIcon(MainFrm.class.getResource("/images/\u73ED\u7EA7\u5217\u8868.png")));
		addFoodMenuItem.add(menuItem_5);
		
		manageFoodMenu = new JMenu("\u98DF\u54C1\u7BA1\u7406");
		manageFoodMenu.setIcon(new ImageIcon(MainFrm.class.getResource("/images/\u73ED\u7EA7\u4ECB\u7ECD.png")));
		menuBar.add(manageFoodMenu);
		
		addFoodMenuItem = new JMenuItem("\u6DFB\u52A0\u98DF\u54C1");
		addFoodMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddFoodFrm addFoodFrm = new AddFoodFrm();
				addFoodFrm.setVisible(true);
				desktopPane.add(addFoodFrm);
			}
		});
		addFoodMenuItem.setIcon(new ImageIcon(MainFrm.class.getResource("/images/\u6DFB\u52A0.png")));
		manageFoodMenu.add(addFoodMenuItem);
		
		JMenuItem menuItem_8 = new JMenuItem("\u98DF\u54C1\u5217\u8868");
		menuItem_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManageFoodFrm manageFoodFrm = new ManageFoodFrm();
				manageFoodFrm.setVisible(true);
				desktopPane.add(manageFoodFrm);
			}
		});
		menuItem_8.setIcon(new ImageIcon(MainFrm.class.getResource("/images/\u73ED\u7EA7\u5217\u8868.png")));
		manageFoodMenu.add(menuItem_8);
		
		JMenu menu_2 = new JMenu("\u6E38\u620F\u7BA1\u7406");
		menu_2.setIcon(new ImageIcon(MainFrm.class.getResource("/images/\u804C\u79F0\u8BC4\u5B9A.png")));
		menuBar.add(menu_2);
		
		
		JMenuItem menuItem_2 = new JMenuItem("\u6DFB\u52A0\u6E38\u620F");
		menuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddGameFrm addGameFrm = new AddGameFrm();
				addGameFrm.setVisible(true);
				desktopPane.add(addGameFrm);
			}
		});
		menuItem_2.setIcon(new ImageIcon(MainFrm.class.getResource("/images/\u6DFB\u52A0.png")));
		menu_2.add(menuItem_2);
		
		JMenuItem menuItem_7 = new JMenuItem("\u6E38\u620F\u5217\u8868");
		menuItem_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManageGameFrm manageGameFrm = new ManageGameFrm();
				manageGameFrm.setVisible(true);
				desktopPane.add(manageGameFrm);
			}
		});
		menuItem_7.setIcon(new ImageIcon(MainFrm.class.getResource("/images/\u73ED\u7EA7\u5217\u8868.png")));
		menu_2.add(menuItem_7);
		
		JMenu menu_3 = new JMenu("\u5E2E\u52A9");
		menu_3.setIcon(new ImageIcon(MainFrm.class.getResource("/images/\u5E2E\u52A9.png")));
		menuBar.add(menu_3);
		
		JMenuItem menuItem_6 = new JMenuItem("\u5173\u4E8E\u6211\u4EEC");
		menuItem_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				aboutUs(ae);
			}
		});
		menuItem_6.setIcon(new ImageIcon(MainFrm.class.getResource("/images/\u5173\u4E8E\u6211\u4EEC.png")));
		menu_3.add(menuItem_6);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		desktopPane = new JDesktopPane();
		desktopPane.setBackground(Color.LIGHT_GRAY);
		contentPane.add(desktopPane, BorderLayout.CENTER);
		
		JLabel label = new JLabel("\u5BA2\u6237\u59D3\u540D\uFF1A");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		label.setBounds(14, 77, 90, 43);
		desktopPane.add(label);
		
		customerNameTextField = new JTextField();
		customerNameTextField.setColumns(10);
		customerNameTextField.setBounds(118, 87, 151, 24);
		desktopPane.add(customerNameTextField);
		
		JLabel label_2 = new JLabel("\u673A\u5668\u53F7\u7801:");
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		label_2.setBounds(14, 184, 79, 19);
		desktopPane.add(label_2);
		
		customerComputertextField = new JTextField();
		customerComputertextField.setColumns(10);
		customerComputertextField.setBounds(118, 182, 151, 24);
		desktopPane.add(customerComputertextField);
		
		JLabel label_3 = new JLabel("\u767B\u5F55\u5BC6\u7801\uFF1A");
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		label_3.setBounds(14, 275, 90, 19);
		desktopPane.add(label_3);
		
		customerPasswordField = new JPasswordField();
		customerPasswordField.setBounds(118, 273, 151, 24);
		desktopPane.add(customerPasswordField);
		
		JButton submitButton = new JButton("\u786E\u8BA4");
		submitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				customerAddAct(ae);
			}
		});
		submitButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		submitButton.setBounds(14, 340, 81, 27);
		desktopPane.add(submitButton);
		
		JButton resetButton = new JButton("\u91CD\u7F6E");
		resetButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				resetValue(ae);
			}
		});
		resetButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		resetButton.setBounds(184, 339, 85, 29);
		desktopPane.add(resetButton);
		
		//��Ϣչʾ��
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(322, 128, 552, 550);
		desktopPane.add(scrollPane);
		
//		table = new JTable();
//		table.setModel(new DefaultTableModel(
//			new Object[][] {
//			},
//			new String[] {
//				"\u673A\u5668\u53F7", "\u4F7F\u7528\u72B6\u6001", "\u4F7F\u7528\u8005", "\u6240\u5C5E\u673A\u533A"
//			}
//		));
		table=new JTable(model);
		Vector names = new Vector();
		for(int i=0;i<5;i++) {
			names.add(title[i]);
		}
		
		Vector Data = new Vector();
		ComputerDao comDao=new ComputerDao();
		List<Computer> retList=comDao.getComputerList();
		
		for(int i=0;i<retList.size();i++) {
			Vector row=new Vector();
			row.add(retList.get(i).getNum());
			row.add(retList.get(i).getState());
			row.add(retList.get(i).getUser());
			row.add(retList.get(i).getArea());
			row.add(retList.get(i).getBeginTime());
			Data.add(row);
			
		}
		comDao.closeDao();
		model.setDataVector(Data, names);
		scrollPane.setViewportView(table);
		
		//�ĸ�����ѡ��
		ButtonGroup stateGroup=new ButtonGroup();
		JRadioButton rdbtnNewRadioButton = new JRadioButton("\u6240\u6709");
		rdbtnNewRadioButton.setBackground(Color.LIGHT_GRAY);
		rdbtnNewRadioButton.setSelected(true);
		rdbtnNewRadioButton.addItemListener(new myItemListener());
		rdbtnNewRadioButton.setBounds(322, 86, 79, 27);
		desktopPane.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("\u672A\u4F7F\u7528");
		rdbtnNewRadioButton_1.setBackground(Color.LIGHT_GRAY);
		rdbtnNewRadioButton_1.addItemListener(new myItemListener());
		rdbtnNewRadioButton_1.setBounds(461, 86, 79, 27);
		desktopPane.add(rdbtnNewRadioButton_1);
		
		JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("\u4F7F\u7528\u4E2D");
		rdbtnNewRadioButton_2.setBackground(Color.LIGHT_GRAY);
		rdbtnNewRadioButton_2.addItemListener(new myItemListener());
		rdbtnNewRadioButton_2.setBounds(632, 86, 79, 27);
		desktopPane.add(rdbtnNewRadioButton_2);
		
		JRadioButton radioButton = new JRadioButton("\u5DF2\u635F\u574F");
		radioButton.setBackground(Color.LIGHT_GRAY);
		radioButton.addItemListener(new myItemListener());
		radioButton.setBounds(793, 86, 81, 27);
		desktopPane.add(radioButton);
		stateGroup.add(rdbtnNewRadioButton);
		stateGroup.add(rdbtnNewRadioButton_1);
		stateGroup.add(rdbtnNewRadioButton_2);
		stateGroup.add(radioButton);
		
		sexButtonGroup = new ButtonGroup();
		setLocationRelativeTo(null);
		setAuthority();
	}
	public void updatetable(List<Computer> retList) {
		DefaultTableModel model=(DefaultTableModel)table.getModel();
		model.setRowCount(0);
		Vector names = new Vector();
		for(int i=0;i<5;i++) {
			names.add(title[i]);
		}
		Vector Data = new Vector();
		for(int i=0;i<retList.size();i++) {
			Vector row=new Vector();
			row.add(retList.get(i).getNum());
			row.add(retList.get(i).getState());
			row.add(retList.get(i).getUser());
			row.add(retList.get(i).getArea());
			row.add(retList.get(i).getBeginTime());
			Data.add(row);
		}
		model.setDataVector(Data, names);
	}
	//��д���±��񷽷�
	public void updatetable(JTable table,String selecttype) {
		List<Computer> retList;
		ComputerDao comDao=new ComputerDao();
		if(selecttype.equals("����")) {
			retList=comDao.getComputerList();
		}
		else {
			retList=comDao.getComputerList(selecttype);
		}
		DefaultTableModel model=(DefaultTableModel)table.getModel();
		model.setRowCount(0);
		Vector names = new Vector();
		for(int i=0;i<5;i++) {
			names.add(title[i]);
		}
		Vector Data = new Vector();
		for(int i=0;i<retList.size();i++) {
			Vector row=new Vector();
			row.add(retList.get(i).getNum());
			row.add(retList.get(i).getState());
			row.add(retList.get(i).getUser());
			row.add(retList.get(i).getArea());
			row.add(retList.get(i).getBeginTime());
			Data.add(row);
		}
		model.setDataVector(Data, names);
		comDao.closeDao();
	}
	//RadioButton�����¼�
	class myItemListener implements ItemListener {
		public void itemStateChanged(ItemEvent e) {
			if(e.getStateChange()==1) {
				DefaultTableModel model=(DefaultTableModel)table.getModel();
				model.setRowCount(0);
				Vector names = new Vector();
				for(int i=0;i<5;i++) {
					names.add(title[i]);
				}
				ComputerDao comDao=new ComputerDao();
				Vector Data = new Vector();
				String s=e.getSource().toString();
				String s1=s.substring(s.length()-3, s.length()-1);
				String s2=s.substring(s.length()-4, s.length()-1);
				List<Computer> retList;
				if(s1.equals("����")) {
					retList=comDao.getComputerList();
					radiobuttonselected=s1;
				}
				else {
					retList=comDao.getComputerList(s2);
					radiobuttonselected=s2;
				}
				
				for(int i=0;i<retList.size();i++) {
					Vector row=new Vector();
					row.add(retList.get(i).getNum());
					row.add(retList.get(i).getState());
					row.add(retList.get(i).getUser());
					row.add(retList.get(i).getArea());
					row.add(retList.get(i).getBeginTime());
					Data.add(row);
				}
				model.setDataVector(Data, names);
				comDao.closeDao();
			}
		}
	}
	
	protected void addCustomerArea(ActionEvent ae) {
		// TODO Auto-generated method stub
		AddAreaFrm sca = new AddAreaFrm();
		sca.setVisible(true);
		desktopPane.add(sca);
	}

	protected void editPassword(ActionEvent ae) {
		// TODO Auto-generated method stub
		EditPasswordFrm editPasswordFrm = new EditPasswordFrm();
		editPasswordFrm.setVisible(true);
		desktopPane.add(editPasswordFrm);
	}

	protected void aboutUs(ActionEvent ae) {
		
	}
	
	protected void customerAddAct(ActionEvent ae) {
		// TODO Auto-generated method stub
		String customerName = customerNameTextField.getText().toString();
		String customerPassword = customerPasswordField.getText().toString();
		Date date = new Date();//���ϵͳʱ��.

		String nowTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);//��ʱ���ʽת���ɷ���TimestampҪ��ĸ�ʽ.
		
		int customerComputer = 0;
		if(StringUtil.isEmpty(customerName)){
			JOptionPane.showMessageDialog(this, "����д�˿�����!");
			return;
		}
		if(StringUtil.isEmpty(customerPassword)){
			JOptionPane.showMessageDialog(this, "����д��¼����!");
			return;
		}
		try {
			customerComputer = Integer.parseInt(customerComputertextField.getText().toString());
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(this, "������ֻ�����������֣�");
			return;
		}
		Customer customer = new Customer();
		customer.setName(customerName);
		customer.setPassword(customerPassword);
		customer.setComputer(customerComputer);
		customer.setontime(nowTime);
		customer.setId(Integer.parseInt(customerPassword));
		ComputerDao comDao=new ComputerDao();
		Computer c=comDao.findComputer(customerComputer);
		System.out.println(Integer.parseInt(c.getArea()));
		customer.setAreaId(Integer.parseInt(c.getArea()));
		CustomerDaoOnMain customerDao = new CustomerDaoOnMain();
		BillDao billDao=new BillDao();
		Bill bill=new Bill();
		bill.setBid(customerPassword+nowTime);
		bill.setUserid(Integer.parseInt(customerPassword));
		bill.setUsername(customerName);
		bill.setComid(customerComputer);
		bill.setBegintime(nowTime);
		
		if(customerDao.addCustomer(customer)){
			JOptionPane.showMessageDialog(this, "���ӳɹ�!");
			billDao.addBill(bill);
			billDao.closeDao();
			if(radiobuttonselected.equals("����")) {
				updatetable(comDao.getComputerList());
			}
			else {
				updatetable(comDao.getComputerList(radiobuttonselected));
			}
		}else{
			JOptionPane.showMessageDialog(this, "����ʧ��!");
		}
		comDao.closeDao();
		resetValue(ae);
	}
	
	protected void resetValue(ActionEvent ae) {
		// TODO Auto-generated method stub
		customerNameTextField.setText("");
		customerPasswordField.setText("");
		customerComputertextField.setText(null);
	}
	
	private void setAuthority(){
		if("�ͻ�".equals(userType.getName())){
			addFoodMenuItem.setEnabled(false);
			addFoodMenuItem.setEnabled(false);
			manageFoodMenu.setEnabled(false);
		}
	}
}
