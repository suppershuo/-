package com.artisan.model;

public class Computer {
	private int num;
	private String state;
	private String user;
	private String area;
	private String beginTime;
	private int userid;
	public void setNum(int num) {
		this.num=num;
	}
	public int getNum() {
		return num;
	}
	public void setState(String s) {
		state=s;
	}
	public String getState() {
		return state;
	}
	public void setUser(String u) {
		user=u;
	}
	public String getUser() {
		return user;
	}
	public void setArea(String s) {
		area=s;
	}
	public String getArea() {
		return area;
	}
	public void setBeginTime(String s) {
		beginTime=s;
	}
	public String getBeginTime() {
		return beginTime;
	}
	public void setUserid(int id) {
		userid=id;
	}
	public int getUserid() {
		return userid;
	}
}
