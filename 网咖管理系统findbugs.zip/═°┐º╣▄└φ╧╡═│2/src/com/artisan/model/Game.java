package com.artisan.model;
/**
 * 
 * @author llq
 *��Ϸ��Ϣ��
 */
public class Game {
	private String sname;
	private String stype;
	
	private float sprice;
	private String product;
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getsname() {
		return sname;
	}
	public void setsname(String sname) {
		this.sname = sname;
	}
	public String getstype() {
		return stype;
	}
	public void setstype(String stype) {
		this.stype = stype;
	}
	
	public float getsprice() {
		return sprice;
	}
	public void setsprice(float sprice) {
		this.sprice = sprice;
	}
}
